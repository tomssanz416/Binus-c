#include <stdio.h>

int main(){
	int age;
	scanf("%d", &age);
	switch(age){
		case 0 ... 1 :
			printf("Baby");
			break;
		case 2 ... 3 :
			printf("Toddler");
			break;
		case 4 ... 5 :
			printf("Preschooler");
			break;
		case 6 ... 12 :
			printf("Child");
			break;
		case 13 ... 17 :
			printf("Teenager");
			break;
		case 18 ... 21 :
			printf("Young Adult");
			break;
		case 22 ... 30 :
			printf("Pre-adult");
			break;
		case 31 ... 50 :
			printf("Adult");
			break;
		case 51 ... 70 :
			printf("Pre-elderly");
			break;
		default : 
			printf("Elderly");
	}
	return 0;
}
