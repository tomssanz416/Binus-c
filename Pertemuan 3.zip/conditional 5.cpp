#include <stdio.h>
#include <math.h>

int main() {
    float a, b, c;
    float D, x1, x2;

    printf("Enter value A: ");
    scanf("%f", &a);
    printf("Enter value B: ");
    scanf("%f", &b);
    printf("Enter value C: ");
    scanf("%f", &c);

    if (a == 0) {
        printf("It is not a quadratic equation\n");
    } else {
        D = (b * b) - (4 * a * c);

        printf("Quadratic Equation: %.2fx^2 + %.2fx + %.2f = 0\n", a, b, c);
        printf("Discriminant = %.2f\n", D);

        if (D > 0) {
            x1 = (-b + sqrt(D)) / (2 * a);
            x2 = (-b - sqrt(D)) / (2 * a);

            printf("It has distinct roots\n");
            printf("x1 = %.2f\n", x1);
            printf("x2 = %.2f\n", x2);

        } else if (D == 0) {
            x1 = -b / (2 * a);

            printf("It has a double root\n");
            printf("x = %.2f\n", x1);

        } else {
            printf("It has imaginary roots\n");
            printf("x1 = (-b + v(%.2f)) / (2a)\n", D);
            printf("x2 = (-b - v(%.2f)) / (2a)\n", D);
        }
    }

    return 0;
}

