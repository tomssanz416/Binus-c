#include <stdio.h>

int main() {
    int menu;
    float input, result;

    printf("Temperature Conversion Menu\n");
    printf("1. Celsius to Fahrenheit\n");
    printf("2. Celsius to Kelvin\n");
    printf("3. Fahrenheit to Celsius\n");
    printf("4. Fahrenheit to Kelvin\n");
    printf("5. Kelvin to Celsius\n");
    printf("6. Kelvin to Fahrenheit\n");
    printf("Choose menu (1-6): ");
    scanf("%d", &menu);

    printf("Input temperature: ");
    scanf("%f", &input);

    switch(menu) {
        case 1:
            result = (input * 9 / 5) + 32;
            printf("Result: %.2f Fahrenheit\n", result);
            break;
        case 2:
            result = input + 273.15;
            printf("Result: %.2f Kelvin\n", result);
            break;
        case 3:
            result = (input - 32) * 5 / 9;
            printf("Result: %.2f Celsius\n", result);
            break;
        case 4:
            result = (input - 32) * 5 / 9 + 273.15;
            printf("Result: %.2f Kelvin\n", result);
            break;
        case 5:
            result = input - 273.15;
            printf("Result: %.2f Celsius\n", result);
            break;
        case 6:
            result = (input - 273.15) * 9 / 5 + 32;
            printf("Result: %.2f Fahrenheit\n", result);
            break;
        default:
            printf("Invalid menu choice\n");
    }

    return 0;
}

