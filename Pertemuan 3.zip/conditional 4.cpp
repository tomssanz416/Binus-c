#include <stdio.h>

int main(){
	float a, b, c;
	int bentuk = 0;
	float x, y, z, temp;
	
	scanf("%f %f %f", &a, &b, &c);
	
	if (a <= 0 || b <= 0 || c <= 0 ||
        a + b <= c || a + c <= b || b + c <= a) {
        bentuk = 1; // Not a Triangle
    }
    else if (a == b && b == c) {
        bentuk = 2; // Equilateral
    }
    else {
        x = a; y = b; z = c;
        if (x > y) { temp = x; x = y; y = temp; }
        if (y > z) { temp = y; y = z; z = temp; }
        if (x > y) { temp = x; x = y; y = temp; }

        if ((x * x + y * y) == (z * z)) {
            bentuk = 5; // Right-angled
        }
        else if (a == b || a == c || b == c) {
            bentuk = 3; // Isosceles
        }
        else {
            bentuk = 4; // Scalene
        }
    }

    switch (bentuk) {
        case 1:
            printf("Not a Triangle\n");
            break;
        case 2:
            printf("Equilateral Triangle\n");
            break;
        case 3:
            printf("Isosceles Triangle\n");
            break;
        case 4:
            printf("Scalene Triangle\n");
            break;
        case 5:
            printf("Right-angled Triangle\n");
            break;
        default:
            printf("Unknown Type\n");
    }

    return 0;
}

