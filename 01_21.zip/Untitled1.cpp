#include <iostream>
using namespace std;

void namaAsal() {
    cout << "OUTPUT:\n";
    cout << "------------------------\n";
    cout << "| Tommy Sanjaya        |\n";
    cout << "| Taiwan / TKU         |\n";
    cout << "------------------------\n";
}

int tambah(int a = 0, int b = 0) {
    return a + b;
}

int kurang(int a = 0, int b = 0) {
    return a - b;
}

int kali(int a = 0, int b = 0) {
    return a * b;
}

int bagi(int a = 0, int b = 1) {
    return a / b;
}

int mod(int a = 0, int b = 1) {
    return a % b;
}

int main() {
    namaAsal();

    while (true) {
        string menu;
        cout << "\nMasukkan Menu(+|-|/|*|%|stop): ";
        cin >> menu;

        if (menu == "stop") {
            cout << "Program Berhenti, Terima Kasih telah menggunakan program saya.\n";
            break;
        }

        int n1, n2;
        cout << "Masukkan Nilai 1: ";
        cin >> n1;
        cout << "Masukkan Nilai 2: ";
        cin >> n2;

        if (menu == "+") {
            cout << "Hasil Penjumlahan " << n1 << " + " << n2 << " adalah " << tambah(n1, n2) << endl;
        }
        else if (menu == "-") {
            cout << "Hasil Pengurangan " << n1 << " - " << n2 << " adalah " << kurang(n1, n2) << endl;
        }
        else if (menu == "*") {
            cout << "Hasil Perkalian " << n1 << " * " << n2 << " adalah " << kali(n1, n2) << endl;
        }
        else if (menu == "/") {
            if (n2 == 0) {
                cout << "Tidak bisa dibagi dengan 0\n";
            } else {
                cout << "Hasil Pembagian " << n1 << " / " << n2 << " adalah " << bagi(n1, n2) << endl;
            }
        }
        else if (menu == "%") {
            if (n2 == 0) {
                cout << "Tidak bisa modulus dengan 0\n";
            } else {
                cout << "Hasil Modulus " << n1 << " % " << n2 << " adalah " << mod(n1, n2) << endl;
            }
        }
        else {
            cout << "Menu salah, coba lagi\n";
        }
    }

    return 0;
}

