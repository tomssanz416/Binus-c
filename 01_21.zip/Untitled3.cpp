#include <iostream>
using namespace std;

class DataMahasiswa {
private:
    string nama;
    int nilai;
    bool adaData; // penanda apakah data sudah ada atau belum

public:
    DataMahasiswa() {
        nama = "null";
        nilai = -1;
        adaData = false;
    }

    // setter
    void setNama(string n) {
        nama = n;
        adaData = true;
    }

    void setNilai(int v) {
        nilai = v;
        adaData = true;
    }

    // getter
    string getNama() {
        if (!adaData) return "null";
        return nama;
    }

    string getNilai() {
        if (!adaData || nilai == -1) return "null";
        return to_string(nilai);
    }

    // hapus data
    void hapus() {
        nama = "null";
        nilai = -1;
        adaData = false;
    }
};

int main() {
    DataMahasiswa obj;

    int pilih;

    while (true) {
        cout << "\n===== Program OOP =====\n";
        cout << "1. Mendeklarasikan Objek\n";
        cout << "2. Menampilkan Objek\n";
        cout << "3. Merubah Nilai Objek\n";
        cout << "4. Menghapus Objek\n";
        cout << "5. Keluar Dari Program\n";
        cout << "Masukkan Pilihan Berupa Angka (1/2/3/4/5): ";
        cin >> pilih;

        if (pilih == 1) {
            string nama;
            int nilai;

            cout << "Masukkan Namamu: ";
            cin >> nama;

            cout << "Masukkan Nilaimu: ";
            cin >> nilai;

            obj.setNama(nama);
            obj.setNilai(nilai);

            cout << "Data Berhasil Ditambahkan\n";
        }
        else if (pilih == 2) {
            cout << "\nNama: " << obj.getNama() << endl;
            cout << "Nilai: " << obj.getNilai() << endl;
        }
        else if (pilih == 3) {
            string ubah;
            cout << "Apa yang ingin diubah (Nama/Nilai): ";
            cin >> ubah;

            if (ubah == "Nama" || ubah == "nama") {
                string n;
                cout << "Masukkan Nama: ";
                cin >> n;
                obj.setNama(n);
                cout << "Data Nama Berhasil Dirubah\n";
            }
            else if (ubah == "Nilai" || ubah == "nilai") {
                int v;
                cout << "Masukkan Nilai: ";
                cin >> v;
                obj.setNilai(v);
                cout << "Data Nilai Berhasil Dirubah\n";
            }
            else {
                cout << "Pilihan tidak sesuai\n";
            }
        }
        else if (pilih == 4) {
            obj.hapus();
            cout << "Data Berhasil Dihapus\n";
        }
        else if (pilih == 5) {
            cout << "Terima Kasih Sudah Menggunakan Program Saya\n";
            break;
        }
        else {
            cout << "Input salah, masukkan 1-5\n";
        }
    }

    return 0;
}

