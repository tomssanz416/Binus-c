#include <iostream>
using namespace std;

void tampil(string listNama[], int n) {
    for (int i = 0; i < n; i++) {
        cout << "Index Ke-" << i << ": " << listNama[i] << endl;
    }
    cout << "Data Berhasil Ditampilkan\n";
}

void ganti(string listNama[], int n) {
    int idx;
    string namaBaru;

    cout << "Masukkan Index yang Ingin diganti: ";
    cin >> idx;

    if (idx < 0 || idx >= n) {
        cout << "Index Tidak Valid\n";
        return;
    }

    cout << "Masukkan Yang ingin diubah: ";
    cin >> namaBaru;

    listNama[idx] = namaBaru;
    cout << "Data Dalam List Berhasil Diganti\n";
}

void hapus(string listNama[], int n) {
    int idx;

    cout << "Masukkan Index yang Ingin dihapus: ";
    cin >> idx;

    if (idx < 0 || idx >= n) {
        cout << "Index Tidak Valid\n";
        return;
    }

    listNama[idx] = "";
    cout << "Data Berhasil Dihapus\n";
}

int main() {
    const int n = 6;
    string listNama[n] = {"Azhar", "Jordie", "Ridho", "Ardi", "Clementius", "Jasmine"};

    int menu;

    while (true) {
        cout << "\nMenu\n";
        cout << "1. Tampil\n";
        cout << "2. Ganti\n";
        cout << "3. Hapus\n";
        cout << "0. Keluar\n";
        cout << "Masukkan Menu: ";
        cin >> menu;

        if (menu == 1) {
            tampil(listNama, n);
        } else if (menu == 2) {
            ganti(listNama, n);
        } else if (menu == 3) {
            hapus(listNama, n);
        } else if (menu == 0) {
            cout << "Terima Kasih telah menggunakan program saya\n";
            break;
        } else {
            cout << "Inputan Tidak Valid\n";
        }
    }

    return 0;
}

