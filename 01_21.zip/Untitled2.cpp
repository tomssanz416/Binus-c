#include <iostream>
using namespace std;

class Mahasiswa {
public:
    string nama;
    string nim;
    string jurusan;
    string asal;

    void inputData() {
        cout << "Masukkan Nama    : ";
        getline(cin, nama);

        cout << "Masukkan NIM     : ";
        getline(cin, nim);

        cout << "Masukkan Jurusan : ";
        getline(cin, jurusan);

        cout << "Masukkan Asal    : ";
        getline(cin, asal);
    }

    void tampilBiodata() {
        cout << "\n===== BIODATA MAHASISWA =====\n";
        cout << "Nama    : " << nama << endl;
        cout << "NIM     : " << nim << endl;
        cout << "Jurusan : " << jurusan << endl;
        cout << "Asal    : " << asal << endl;
        cout << "=============================\n";
    }
};

int main() {
    Mahasiswa mhs;

    cout << "INPUT DATA MAHASISWA\n";
    mhs.inputData();
    mhs.tampilBiodata();

    return 0;
}

